
from django.urls import path,include
from . import views

urlpatterns = [
    path('',views.home, name='Home'),
    #project urls
    path('projects/',views.DailyTask,name='DailyTask'),
    path('projDetails/<str:hm>',views.projectDetails,name='details'),  #dynamic url
    path('projAdd/',views.Taskadd,name='Taskadd'),
    path('projectdelete/<str:id>/',views.Taskdelete,name="Taskdelete"),
    path('projectupdate/<str:id>/',views.Taskupdate,name="Taskupdate"),
    path('profileAdd/',views.profileadd,name="AddProfile"),


    
    
    #cv urls
    path('cvv/',views.dashboard,name='Dashboard'),
    path('login/',views.loginpage,name='login'),
    path('logout/',views.logoutpage,name='logout'),
    path('signup/',views.signup,name='signup'),

]