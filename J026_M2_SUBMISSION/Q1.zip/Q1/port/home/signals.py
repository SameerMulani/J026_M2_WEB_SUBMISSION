from django.db.models.signals import post_save,post_delete
from .models import Project,SpecialSkills  #sender,receiver
from django.dispatch import receiver

@receiver(post_save,sender=Project)  #will be activated after using post_save,sender=Project
def autoGenerateSpecialSkills(sender,instance,created,**kwargs):   #**kwargs means we can change the number of arguments passed in it
    print('Signal Fire Automatic')
    if created: #once it is successfully created,then only the instance(object) generated at the sender will get passed on
        projectData = instance
        SpecialSkills.objects.create(
            name = projectData.name,   #storing project's name in SpecialSkills' name
            description = projectData.description,)
        print('Special Skills created!!')

@receiver(post_delete,sender=Project)  #when deleted in project then it should get deleted in SpecialSkills
def autoSpecialSkills(sender,instance,**kwargs):
    data = instance
    #in delete there should be a common field to match,using that we will delete
    #in this case it is the name
    fetchData = SpecialSkills.objects.get(name=data.name)
    fetchData.delete()
    print('Deleted successfully!!')
